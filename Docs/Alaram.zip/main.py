from machine import Pin, I2C
from ssd1306 import SSD1306_I2C
import utime
import sys

i2c = I2C(1, sda=Pin(26), scl=Pin(27), freq=200000)
devices = i2c.scan()
if not devices:
    print("OLED display not found!")
    sys.exit()

oled = SSD1306_I2C(128, 64, i2c)
buzzer = Pin(6, Pin.OUT)

btn_plus5 = Pin(2, Pin.IN, Pin.PULL_UP)
btn_stop = Pin(3, Pin.IN, Pin.PULL_UP)
btn_start = Pin(4, Pin.IN, Pin.PULL_UP)
btn_next = Pin(5, Pin.IN, Pin.PULL_UP)

tasks = [
    {"name": "Study / Work", "time": 25 * 60},
    {"name": "Project / Code", "time": 45 * 60},
    {"name": "Chores / Home", "time": 15 * 60},
]

mode = "clock"
selected_task = 0
timer_remaining = 0
timer_running = False
timer_paused = False
alarm_hour = 8
alarm_minute = 0
alarm_enabled = False
last_btn_time = 0
BTN_DEBOUNCE = 250

def beep(ms):
    buzzer.value(1)
    utime.sleep_ms(ms)
    buzzer.value(0)

def success_sound():
    for _ in range(5):
        buzzer.value(1)
        utime.sleep_ms(50)
        buzzer.value(0)
        utime.sleep_ms(50)

def alarm_sound():
    for _ in range(10):
        buzzer.value(1)
        utime.sleep_ms(200)
        buzzer.value(0)
        utime.sleep_ms(200)

def draw_char(state, x=95, y=35):
    oled.fill_rect(x, y, 18, 22, 1)
    
    if state == 'idle':
        oled.fill_rect(x+4, y+4, 2, 2, 0)
        oled.fill_rect(x+10, y+4, 2, 2, 0)
        oled.fill_rect(x+6, y+13, 5, 2, 0)
    elif state == 'working':
        oled.fill_rect(x+4, y+4, 2, 2, 0)
        oled.fill_rect(x+10, y+4, 2, 2, 0)
        oled.fill_rect(x+6, y+13, 5, 2, 0)
        oled.fill_rect(x+18, y+8, 6, 3, 1)
    elif state == 'tired':
        oled.fill_rect(x+4, y+6, 2, 1, 0)
        oled.fill_rect(x+10, y+6, 2, 1, 0)
        oled.fill_rect(x+6, y+15, 5, 2, 0)
    elif state == 'happy':
        oled.fill_rect(x+4, y+4, 2, 2, 0)
        oled.fill_rect(x+10, y+4, 2, 2, 0)
        oled.fill_rect(x+4, y+13, 8, 3, 0)
        for i in range(3):
            oled.pixel(x + i*4, y - i*3, 1)
    elif state == 'worried':
        oled.fill_rect(x+4, y+4, 2, 2, 0)
        oled.fill_rect(x+10, y+4, 2, 2, 0)
        oled.fill_rect(x+6, y+15, 5, 1, 0)
        oled.fill_rect(x+3, y+2, 4, 1, 0)
        oled.fill_rect(x+9, y+2, 4, 1, 0)
    
    oled.show()

def show_clock():
    oled.fill(0)
    t = utime.localtime()
    time_str = "{:02d}:{:02d}".format(t[3], t[4])
    oled.text(time_str, 35, 20, 1)
    oled.text("PomoPico", 30, 48, 1)
    draw_char('idle', 95, 35)
    oled.show()

def show_task_list():
    oled.fill(0)
    oled.text("SELECT TASK", 12, 0, 1)
    oled.hline(0, 12, 128, 1)
    
    for i, task in enumerate(tasks):
        y = 20 + i * 15
        name = task["name"][:13]
        if i == selected_task:
            oled.text("> " + name, 5, y, 1)
        else:
            oled.text("  " + name, 5, y, 1)
    
    oled.text("START=select", 5, 52, 1)
    oled.show()

def show_timer():
    oled.fill(0)
    
    name = tasks[selected_task]["name"][:14]
    oled.text(name, 5, 0, 1)
    
    m = timer_remaining // 60
    s = timer_remaining % 60
    oled.text("{:02d}:{:02d}".format(m, s), 5, 20, 1)
    
    if timer_running and not timer_paused:
        oled.text("WORKING", 5, 38, 1)
    elif timer_paused:
        oled.text("PAUSED", 5, 38, 1)
    else:
        oled.text("READY", 5, 38, 1)
    
    oled.text("+5MIN=anytime", 5, 50, 1)
    
    if timer_running and not timer_paused:
        draw_char('working', 95, 35)
    elif timer_paused:
        draw_char('worried', 95, 35)
    else:
        draw_char('idle', 95, 35)
    
    oled.show()

def show_celebration():
    for _ in range(3):
        oled.fill(0)
        oled.text("DONE!", 40, 15, 1)
        draw_char('happy', 50, 30)
        oled.show()
        utime.sleep_ms(250)
        oled.invert(1)
        utime.sleep_ms(250)
        oled.invert(0)
    success_sound()

def show_alarm():
    oled.fill(0)
    oled.text("ALARM", 40, 0, 1)
    oled.hline(0, 12, 128, 1)
    oled.text("{:02d}:{:02d}".format(alarm_hour, alarm_minute), 40, 25, 1)
    status = "ON" if alarm_enabled else "OFF"
    oled.text("Status: " + status, 20, 45, 1)
    oled.show()

def check_alarm():
    if alarm_enabled:
        t = utime.localtime()
        if t[3] == alarm_hour and t[4] == alarm_minute and t[5] < 2:
            trigger_alarm()

def trigger_alarm():
    alarm_sound()
    oled.fill(0)
    oled.text("WAKE UP!", 25, 20, 1)
    draw_char('idle', 45, 35)
    oled.show()
    utime.sleep_ms(3000)

def update_timer():
    global timer_remaining, timer_running, timer_paused, mode
    
    if timer_running and not timer_paused and timer_remaining > 0:
        timer_remaining -= 1
        
        if 60 < timer_remaining < 300:
            draw_char('tired', 95, 35)
            oled.show()
        
        if timer_remaining <= 0:
            timer_running = False
            show_celebration()
            mode = "task_list"
            show_task_list()

def handle_buttons():
    global mode, selected_task, timer_remaining, timer_running, timer_paused
    global alarm_hour, alarm_minute, alarm_enabled, last_btn_time
    
    now = utime.ticks_ms()
    
    if btn_start.value() == 0:
        if utime.ticks_diff(now, last_btn_time) > BTN_DEBOUNCE:
            last_btn_time = now
            if mode == "clock":
                mode = "task_list"
                show_task_list()
            elif mode == "task_list":
                timer_remaining = tasks[selected_task]["time"]
                timer_running = True
                timer_paused = False
                mode = "timer"
                show_timer()
            elif mode == "timer":
                if timer_paused:
                    timer_paused = False
                    timer_running = True
                    show_timer()
            elif mode == "alarm":
                alarm_enabled = not alarm_enabled
                show_alarm()
            utime.sleep_ms(100)
    
    if btn_next.value() == 0:
        if utime.ticks_diff(now, last_btn_time) > BTN_DEBOUNCE:
            last_btn_time = now
            if mode == "task_list":
                selected_task = (selected_task + 1) % len(tasks)
                show_task_list()
            elif mode == "clock":
                mode = "alarm"
                show_alarm()
            elif mode == "alarm":
                mode = "clock"
                show_clock()
            utime.sleep_ms(100)
    
    if btn_stop.value() == 0:
        if utime.ticks_diff(now, last_btn_time) > BTN_DEBOUNCE:
            last_btn_time = now
            if mode == "timer":
                if timer_running:
                    timer_running = False
                    timer_paused = True
                    show_timer()
                else:
                    mode = "clock"
                    timer_remaining = 0
                    timer_paused = False
                    show_clock()
            utime.sleep_ms(100)
    
    if btn_plus5.value() == 0:
        if utime.ticks_diff(now, last_btn_time) > BTN_DEBOUNCE:
            last_btn_time = now
            if mode == "timer":
                timer_remaining += 5 * 60
                show_timer()
                beep(150)
                oled.invert(1)
                utime.sleep_ms(80)
                oled.invert(0)
            utime.sleep_ms(100)

def main():
    global mode
    
    oled.fill(0)
    oled.text("PomoPico", 30, 15, 1)
    draw_char('happy', 50, 30)
    oled.show()
    beep(200)
    utime.sleep(1)
    
    mode = "clock"
    show_clock()
    
    last_second = utime.ticks_ms()
    
    while True:
        now = utime.ticks_ms()
        
        if utime.ticks_diff(now, last_second) >= 1000:
            last_second = now
            
            check_alarm()
            
            if mode == "clock":
                show_clock()
            elif mode == "timer":
                update_timer()
                show_timer()
        
        handle_buttons()
        
        utime.sleep_ms(30)

if __name__ == "__main__":
    main()